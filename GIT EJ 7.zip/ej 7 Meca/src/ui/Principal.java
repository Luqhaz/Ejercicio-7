
package ui;

import java.util.ArrayList;

public class Principal {

	public static void main(String[] args) {
		Menu m=new Menu();
		m.start();
	}
}